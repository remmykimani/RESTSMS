<?php

class SMS
{
    private $uri;


    function __construct()
    {

        $this->uri = "http://10.55.50.39:8080/v1/sms/"; //URL indicated n the REST SMS App. Append appropriately.
    }

    function send($custNum, $custName, $desc)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->uri);



        $number = $custNum;
        $name = $custName;
        $description = $desc;

        $message = "Hello $name, $description";

        $curl_post_data = array(
            'phone' => $number,
            'message' => $message,
            'sim_slot' => '0'
        );


        $data_string=http_build_query($curl_post_data);



        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

        $curl_response = curl_exec($curl);

        print_r($curl_response);

    }
}

?>