<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <title>SMS TESTER</title>
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form id="message-form" action="index.php" method="POST">
                    <div class="form-group">
                        <label>Recipient Name</label>
                        <input type="text" class="form-control" name="fullName">
                    </div>
                    <div class="form-group">
                        <label>Number</label>
                        <input type="number" class="form-control" name="number" placeholder="eg. 2547......" >
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <input type="textarea" class="form-control" name="desc" >
                    </div>
                    <button type="submit" name='form-sumbit' class="btn btn-success">Send Message</button>
                </form>
            </div>
        </div>
    </div>

</body>

</html>


<?php
require 'SMS.php';
if (isset($_POST['form-sumbit'])) {
    
    $name=$_POST['fullName'];
    $num=$_POST['number'];
    $desc=$_POST['desc'];

    $sms=new SMS();

    $sms->send($num,$name,$desc);
}
?>